package hw4;

import api.Crossable;
import api.Point;
import api.PositionVector;

/**
 * Abstract base for all link types.
 *
 * <p>Design&nbsp;notes:&nbsp;Every concrete link need only implement
 * {@code getNumPaths()} and {@code getConnectedPoint(Point)}.
 * A shared {@code shiftPoints(PositionVector)} here delegates
 * to {@code shiftPointsCommon}, eliminating duplicate code in the
 * seven concrete link classes.</p>
 *
 * @author Yousif Lubbad
 */
public abstract class AbstractLink implements Crossable
{
    /* --------------------------------------------------------------
     * Default no-op callbacks; override in subclasses if needed.
     * -------------------------------------------------------------- */
    @Override
    public void trainEnteredCrossing() { }

    @Override
    public void trainExitedCrossing()  { }

    /* --------------------------------------------------------------
     * Traversable implementation shared by (almost) every link.
     * -------------------------------------------------------------- */
    @Override
    public void shiftPoints(PositionVector pv)
    {
        shiftPointsCommon(pv, getConnectedPoint(pv.getPointB()));
    }

    /**
     * Moves {@code pv} from the entry endpoint onto the first interior
     * segment of the connected path.
     *
     * <ul>
     *   <li>If the entry index is 0&nbsp;(low end) → step forward (+1)</li>
     *   <li>If the entry index is last (high end) → step back    (-1)</li>
     * </ul>
     * Interior points are ignored because links should only connect
     * path endpoints.
     */
    protected final void shiftPointsCommon(PositionVector pv, Point entry)
    {
        if (entry == null)
            return;                      // no connection – stay put

        int idx   = entry.getPointIndex();
        int last  = entry.getPath().getNumPoints() - 1;
        int step  = (idx == 0) ? 1 : (idx == last ? -1 : 0);

        if (step == 0)
            return;                      // interior point – invalid

        pv.setPointA(entry);
        pv.setPointB(entry.getPath().getPointByIndex(idx + step));
    }

    /* --------------------------------------------------------------
     * Behaviours each concrete link must supply.
     * -------------------------------------------------------------- */
    @Override
    public abstract int getNumPaths();

    @Override
    public abstract Point getConnectedPoint(Point p);
}