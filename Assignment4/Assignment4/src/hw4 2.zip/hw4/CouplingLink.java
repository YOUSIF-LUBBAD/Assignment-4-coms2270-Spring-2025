package hw4;

import api.Point;
import api.PositionVector;
import java.util.ArrayList;

/**
 * CouplingLink joins the <i>high</i> endpoint of one path to the
 * <i>low</i> endpoint of a second path (and vice-versa).  
 * It is fixed – no switching or locking – so all traversal mechanics
 * are inherited from {@link AbstractLink}.
 *
 * @author Yousif Lubbad
 */
public class CouplingLink extends AbstractLink
{
    /* ------------------------------------------------------------ */
    private final Point path1High;
    private final Point path2Low;

    /**
     * @param path1High  high endpoint of the first path
     * @param path2Low   low  endpoint of the second path
     */
    public CouplingLink(Point path1High, Point path2Low)
    {
        this.path1High = path1High;
        this.path2Low  = path2Low;
    }

    /* ------------------------------------------------------------ */
    @Override
    public int getNumPaths()
    {
        return 2;
    }

    @Override
    public Point getConnectedPoint(Point p)
    {
        if (p.equals(path1High))
            return path2Low;
        if (p.equals(path2Low))
            return path1High;
        return null;            // any other point → no connection
    }
}
