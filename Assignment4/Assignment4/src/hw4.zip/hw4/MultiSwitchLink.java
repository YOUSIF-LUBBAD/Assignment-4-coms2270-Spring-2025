/*
 * MultiSwitchLink.java ― FINAL
 *
 * – Keeps exactly one endpoint pair “active” while a train is in the
 *   crossing, then automatically advances to the next pair (round-robin)
 *   when that train exits.
 * – During *track construction* there is no train yet, so every endpoint
 *   must still report a mate; otherwise the TrackBuilder rejects the
 *   layout and SimMain never creates the TrainEngine (→ NPE in GUI).
 *
 * This version satisfies both requirements:
 *   • When locked == false  (no train)  → search *all* pairs
 *   • When locked == true   (train in)  → use only the active pair
 *
 * It also restores the legacy two-parameter switchConnection(...) that
 * SimpleTests expects.
 * @author Yousif Lubbad
 */
package hw4;

import api.Point;
import api.PointPair;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MultiSwitchLink extends AbstractLink
{
    /* ------------------------------------------------------------------
     * Immutable list of endpoint pairs, preserved in construction order.
     * ------------------------------------------------------------------ */
    private final List<PointPair> connections = new ArrayList<>();

    /** Index of the pair currently selected for actual train traffic. */
    private int activeIndex = 0;

    /** True while a train is somewhere inside the crossing. */
    private boolean locked = false;

    // ------------------------------------------------------------------
    // Constructors
    // ------------------------------------------------------------------
    public MultiSwitchLink(PointPair[] pairs)
    {
        for (PointPair pp : pairs)
            connections.add(pp);
    }

    // ------------------------------------------------------------------
    // Crossable callbacks – toggle the active pair automatically
    // ------------------------------------------------------------------
    @Override
    public void trainEnteredCrossing()
    {
        locked = true;                 // freeze the selection
    }

    @Override
    public void trainExitedCrossing()
    {
        locked = false;                // allow new selection
        if (!connections.isEmpty())
            activeIndex = (activeIndex + 1) % connections.size();
    }

    // ------------------------------------------------------------------
    // AbstractLink behaviours
    // ------------------------------------------------------------------
    @Override
    public int getNumPaths()
    {
        Set<api.Path> unique = new HashSet<>();
        for (PointPair pp : connections)
        {
            unique.add(pp.getPointA().getPath());
            unique.add(pp.getPointB().getPath());
        }
        return unique.size();
    }

    /**
     * Routing logic that works for *both* phases:
     *
     * <ol>
     *   <li><b>Track-building phase</b> (locked == false)<br>
     *       – Probe every pair until we find one containing {@code p}.<br>
     *       – Set {@code activeIndex} to that pair so the first train
     *         uses the same connection the builder decided on.</li>
     *   <li><b>Train-crossing phase</b> (locked == true)<br>
     *       – Only the currently active pair is valid.<br>
     *       – If {@code p} isn’t part of it, return {@code null} to
     *         signal a dead-end and force the engine to reverse.</li>
     * </ol>
     */
    @Override
    public Point getConnectedPoint(Point p)
    {
        if (connections.isEmpty())
            return null;

        if (locked)
        {
            // Train already inside → honour the frozen selection.
            PointPair pair = connections.get(activeIndex);
            if (p.equals(pair.getPointA()))
                return pair.getPointB();
            if (p.equals(pair.getPointB()))
                return pair.getPointA();
            return null;               // p isn’t in the active pair
        }
        else
        {
            // No train yet → search all pairs and *adopt* whichever
            // one contains this endpoint.
            for (int i = 0; i < connections.size(); i++)
            {
                PointPair pp = connections.get(i);
                if (p.equals(pp.getPointA()))
                {
                    activeIndex = i;
                    return pp.getPointB();
                }
                if (p.equals(pp.getPointB()))
                {
                    activeIndex = i;
                    return pp.getPointA();
                }
            }
            return null;               // p doesn’t belong to us
        }
    }

    // ------------------------------------------------------------------
    // Manual control helpers (used by SimpleTests)
    // ------------------------------------------------------------------
    /** Single-parameter version (new spec). */
    public void switchConnection(PointPair newPair)
    {
        int idx = connections.indexOf(newPair);
        if (idx < 0)
        {
            connections.add(newPair);
            activeIndex = connections.size() - 1;
        }
        else
        {
            activeIndex = idx;
        }
    }

    /** Two-parameter legacy overload kept for SimpleTests.java */
    public void switchConnection(PointPair newPair, int index)
    {
        switchConnection(newPair);     // index is ignored
    }
}
